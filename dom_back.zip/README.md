## About Smart Admin

## Installation

```
composer install
```

- Go to `[Your_Folder]/public/` you find `plugins.zip` file, extract it in same folder.

```
php artisan serve
```
## TODO

- [ ] Dashboard Module
- [ ] Profile Module
- [ ] Settings Module
- [ ] Invoice Module
- [ ] Media Library Module

## License

Smart Admin is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
